fx_version 'cerulean'
game 'gta5'

author 'eltiguere01' -- Esta línea debe permanecer igual -- This line must remain the same
description 'Logo en el Centro de la Pantalla'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/logo.png'
}

client_script 'client.lua'


CreateThread(function()
    Wait(60000) -- Espera 5 segundos después de entrar al servidor -- Wait 5 seconds after entering the server
    SendNUIMessage({ action = "showLogo" })
end)
